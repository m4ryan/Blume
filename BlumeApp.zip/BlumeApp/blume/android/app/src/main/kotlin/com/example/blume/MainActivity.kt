package com.example.blume

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
